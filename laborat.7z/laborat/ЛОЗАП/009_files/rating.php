
<!DOCTYPE html>
<html lang=ru class="no-touch no-js" prefix="og: http://ogp.me/ns#">
<head>
<meta charset=UTF-8 />
<div id=preload style='text-align:center;width:100%;height:100%;position:fixed;background-color:#fff;z-index:99;font-family:sans-serif'><img style=margin-top:180px src="themes/vestor/assets/img/logo.svg"><br><br>Загрузка...</div>
<title>VESTOR - поиск товаров и сравнение цен в Москве</title>
<meta name=csrf-param content=_csrf>
<meta name=csrf-token content="ID6AyzLXGqV8OYZYMMTMbAMTb1Aq3h52ahVQ3ZYQH79HerO_VKd30jJptQpUk6Q4TnA4ZXO9VgwYXz-s5H9I3A==">
<meta name=robots content=all>
<meta name=description content="VESTOR - поможет найти и купить недорого, подходящие товары среди большого ассортимента. Огромный выбор товаров из интернет-магазинов с доставкой и по недорогим ценам в Москве.">
<link href="themes/vestor/web_assets/css/vestor_style2.css" rel=stylesheet> <link rel=canonical href="https://vestor-ru.ru/"/>
<meta name=viewport content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta content="ie=edge" http-equiv=x-ua-compatible>
<meta name=format-detection content="telephone=no">
<link rel=icon href=favicon.ico type="image/x-icon">
<link rel="shortcut icon" href=favicon.ico type="image/x-icon">
<link rel=apple-touch-icon sizes=57x57 href="fav/apple-icon-57x57.png">
<link rel=apple-touch-icon sizes=60x60 href="fav/apple-icon-60x60.png">
<link rel=apple-touch-icon sizes=72x72 href="fav/apple-icon-72x72.png">
<link rel=apple-touch-icon sizes=76x76 href="fav/apple-icon-76x76.png">
<link rel=apple-touch-icon sizes=114x114 href="fav/apple-icon-114x114.png">
<link rel=apple-touch-icon sizes=120x120 href="fav/apple-icon-120x120.png">
<link rel=apple-touch-icon sizes=144x144 href="fav/apple-icon-144x144.png">
<link rel=apple-touch-icon sizes=152x152 href="fav/apple-icon-152x152.png">
<link rel=apple-touch-icon sizes=180x180 href="fav/apple-icon-180x180.png">
<link rel=icon type="image/png" sizes=192x192 href="fav/android-icon-192x192.png">
<link rel=icon type="image/png" sizes=120x120 href="fav/favicon-120x120.png">
<link rel=icon type="image/png" sizes=32x32 href="fav/favicon-32x32.png">
<link rel=icon type="image/png" sizes=96x96 href="fav/favicon-96x96.png">
<link rel=icon type="image/png" sizes=16x16 href="fav/favicon-16x16.png">
<link rel=manifest href="/fav/manifest.json">
<meta name=msapplication-TileColor content="#ffffff">
<meta name=msapplication-TileImage content="/fav/ms-icon-144x144.png">
<meta name=theme-color content="#ffffff">
<!--[if lt IE 10]>
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script><![endif]-->
<script type="application/ld+json">{"@context":"http:\/\/schema.org","@type":"Organization","name":"Vestor","url":"https:\/\/vestor-ru.ru","contactPoint":{"@type":"ContactPoint","email":"support@vestor-ru.ru","contactType":"customer service","areaServed":"RU","availableLanguage":"Russian"}}</script>
<style>@font-face{font-family:'Rouble';font-weight:normal;font-style:normal;font-display:swap;src:url(/themes/vestor/assets/fonts/Rouble/rouble.eot);src:url(/themes/vestor/assets/fonts/Rouble/rouble.eot?#iefix) format('embedded-opentype') , url(/themes/vestor/assets/fonts/Rouble/rouble.woff) format('woff') , url(/themes/vestor/assets/fonts/Rouble/rouble.ttf) format('truetype') , url(/themes/vestor/assets/fonts/Rouble/rouble.svg#Rouble) format('svg')}</style>
<!-- Yandex.Metrika counter -->
<script>(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})(window,document,"script","https://mc.yandex.ru/metrika/tag.js","ym");ym(56718862,"init",{clickmap:true,trackLinks:true,accurateTrackBounce:true});</script>
<noscript>
<div><img src="https://mc.yandex.ru/watch/56718862" style="position:absolute;left:-9999px" alt=""/></div>
</noscript> <!-- /Yandex.Metrika counter -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-178025859-1"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','UA-178025859-1');</script>
<script>window.yaContextCb=window.yaContextCb||[]</script>
<script src="//yandex.ru/ads/system/context.js" async></script>
</head>
<body>
<div class=geopartners></div> <script async src="https://aflt.market.yandex.ru/widget/script/api"></script>
<div class=wrapper>
<header class=header data-controller=header>
<div class=container>
<div class=top>
<a class=logo href="/">
<img src="themes/vestor/assets/img/logo.svg" alt=logo />
</a>
<span class="btn link-cat js-menu">
<span class=line></span>
<span class=text>Все категории</span>
</span>
<form class=search action=search>
<input id=searchinput class=input name=query type=text placeholder="Введите название продукта" autocomplete=off />
<button type=submit>
<svg class=icon-search>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#search"></use>
</svg>
</button>
<ul class=find-words-res style=display:none></ul>
</form>
<span class="burger js-menu-m">
<span class=line></span>
</span>
</div>
<div class=bottom>
<div class=city>
<span class=js-city>
<svg class=icon-location>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#location"></use>
</svg>
<span class=wrap>
<span class=label>Ваш город:</span>
<span class=text>Москва</span>
</span>
</span>
</div>
<div class=all-count>
<span>136 504 520 товаров</span>
<span>3 664 категорий</span>
</div>
<div class="city-menu js-city-modal" data-url="">
<div class=city-head>
<div class=city-title>Выбор города</div>
<span class="city-menu-close js-city-close"></span>
</div>
<form class=city-form action="">
<div class=city-input>
<input class="input selectcity" type=text placeholder="Введите название города"/>
<button type=submit>
<svg class=icon-search>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#search"></use>
</svg>
</button>
</div>
</form>
<div class=city-list>
<ul id=list></ul>
</div>
</div>
</div>
<div class="cat-holder cat-holder-d js-menu-modal">
<div id=header-menu class=container data-domain=""></div>
</div>
<div class="cat-holder cat-holder-m js-menu-modal-m">
<span class="cat-holder-close js-menu-m">
<svg class=icon-cross><use xlink:href="/themes/vestor/assets/img/sprite-new.svg#cross"></use></svg>
</span>
<div id=header-menu-m class=container data-domain=""></div>
</div>
</div>
</header>
<div class=container>
<div class=category-popular data-controller=tabs>
<div class=b-title>Популярные категории</div>
<div class="tabs js-tabs-link">
<span class=active data-id=91009>Компьютерная техника</span> <span class="" data-id=91461>Телефоны</span> <span class="" data-id=198119>Электроника</span> <span class="" data-id=198118>Бытовая техника</span> <span class="" data-id=90666>Дом и дача</span> <span class="" data-id=90667>Текстиль</span> <span class="" data-id=90708>Освещение</span> </div>
<div class=contents>
<div class="content js-tabs-content active">
<div class=lds-ring>
<div></div>
<div></div>
<div></div>
<div></div>
</div>
<div class=products-list id=product_slider data-controller=products-slider>
<div class=product>
<a class=photo href="chelyabinsk/product/raizer-009-molex-6pin-perehodnik-sata-riser-009__957916430" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Райзер 009 Molex 6Pin Переходник Sata Riser 009" data-original="https://i.vestor-ru.ru/get-marketpic/1658064/market_aGgu0F0H7uqOwplnDja_7A/200x200" data-lazy="https://i.vestor-ru.ru/get-marketpic/1658064/market_aGgu0F0H7uqOwplnDja_7A/200x200"> </a>
<span class=price>
<span class=current>от 884<span class=rouble>i</span></span>
</span>
<a href="chelyabinsk/product/raizer-009-molex-6pin-perehodnik-sata-riser-009__957916430" target=_blank class=rating>
</a>
<span class=delivery>доставка из Челябинска</span>
<a class=name href="chelyabinsk/product/raizer-009-molex-6pin-perehodnik-sata-riser-009__957916430" target=_blank>Райзер 009 Molex 6Pin Переходник Sata Riser 009</a>
</div>
<div class=product>
<a class=photo href="solnechnogorsk/product/fireware-kontroller-espada-pcie1394a__474552474" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="FireWare контроллер ESPADA PCIe1394a" data-original="https://i.vestor-ru.ru/get-mpic/1525355/img_id5226176077655407107.jpeg/200x200" data-lazy="https://i.vestor-ru.ru/get-mpic/1525355/img_id5226176077655407107.jpeg/200x200"> </a>
<span class=price>
<span class=current>от 1 170<span class=rouble>i</span></span>
</span>
<a href="solnechnogorsk/product/fireware-kontroller-espada-pcie1394a__474552474" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<iclass="no-a"></i>
</span>
<span class=count>19 отзывов</span>
</a>
<span class=delivery>доставка из Солнечногорска</span>
<a class=name href="solnechnogorsk/product/fireware-kontroller-espada-pcie1394a__474552474" target=_blank>FireWare контроллер ESPADA PCIe1394a</a>
</div>
<div class=product>
<a class=photo href="yalta/product/korpus-dlya-hdd-ssd-agestar-3ubcp3__653345278" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Корпус для HDD/SSD AGESTAR 3UBCP3" data-original="https://i.vestor-ru.ru/get-mpic/5042167/img_id9050398807564471997.png/200x200" data-lazy="https://i.vestor-ru.ru/get-mpic/5042167/img_id9050398807564471997.png/200x200"> </a>
<span class=price>
<span class=current>от 590<span class=rouble>i</span></span>
</span>
<a href="yalta/product/korpus-dlya-hdd-ssd-agestar-3ubcp3__653345278" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<i></i>
</span>
<span class=count>13 отзывов</span>
</a>
<span class=delivery>доставка из Ялты</span>
<a class=name href="yalta/product/korpus-dlya-hdd-ssd-agestar-3ubcp3__653345278" target=_blank>Корпус для HDD/SSD AGESTAR 3UBCP3</a>
</div>
<div class=product>
<a class=photo href="barnaul/product/raizer-6sht-nabor-molex-6pin-perehodnik-sata-riser-009__2000462352059" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Райзер 6шт Набор Molex 6Pin Переходник Sata Riser 009" data-original="https://i.vestor-ru.ru/get-marketpic/1711025/market_YCKvbcoZURsmzm1e_OS1hA/200x200" data-lazy="https://i.vestor-ru.ru/get-marketpic/1711025/market_YCKvbcoZURsmzm1e_OS1hA/200x200"> </a>
<span class=price>
<span class=current>от 4 773<span class=rouble>i</span></span>
</span>
<a href="barnaul/product/raizer-6sht-nabor-molex-6pin-perehodnik-sata-riser-009__2000462352059" target=_blank class=rating>
</a>
<span class=delivery>доставка из Барнаула</span>
<a class=name href="barnaul/product/raizer-6sht-nabor-molex-6pin-perehodnik-sata-riser-009__2000462352059" target=_blank>Райзер 6шт Набор Molex 6Pin Переходник Sata Riser...</a>
</div>
<div class=product>
<a class=photo href="mahachkala/product/korpus-dlya-ssd-agestar-3ubnf1c__676121187" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Корпус для SSD AGESTAR 3UBNF1C" data-original="https://i.vestor-ru.ru/get-mpic/5216590/img_id739031036598334449.jpeg/200x200" data-lazy="https://i.vestor-ru.ru/get-mpic/5216590/img_id739031036598334449.jpeg/200x200"> </a>
<span class=price>
<span class=current>от 1 080<span class=rouble>i</span></span>
</span>
<a href="mahachkala/product/korpus-dlya-ssd-agestar-3ubnf1c__676121187" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<i></i>
</span>
<span class=count>8 отзывов</span>
</a>
<span class=delivery>доставка из Махачкалы</span>
<a class=name href="mahachkala/product/korpus-dlya-ssd-agestar-3ubnf1c__676121187" target=_blank>Корпус для SSD AGESTAR 3UBNF1C</a>
</div>
<div class=product>
<a class=photo href="surgut/product/vneshnii-korpus-dlya-zhestkogo-diska-baseus-full-speed-series-2-5-hdd-enclosure-type-c-gen2-cayph-c01__950311001" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Внешний корпус для жесткого диска Baseus Full Speed Series 2.5&quot; HDD Enclosure (Type-C (GEN2)) (CAYPH-C01)" data-original="https://i.vestor-ru.ru/get-mpic/5159019/img_id6441269531394937682.jpeg/200x200" data-lazy="https://i.vestor-ru.ru/get-mpic/5159019/img_id6441269531394937682.jpeg/200x200"> </a>
<span class=price>
<span class=current>от 1 390<span class=rouble>i</span></span>
</span>
<a href="surgut/product/vneshnii-korpus-dlya-zhestkogo-diska-baseus-full-speed-series-2-5-hdd-enclosure-type-c-gen2-cayph-c01__950311001" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<i></i>
</span>
<span class=count>7 отзывов</span>
</a>
<span class=delivery>доставка из Сургута</span>
<a class=name href="surgut/product/vneshnii-korpus-dlya-zhestkogo-diska-baseus-full-speed-series-2-5-hdd-enclosure-type-c-gen2-cayph-c01__950311001" target=_blank>Внешний корпус для жесткого диска Baseus Full Spee...</a>
</div>
<div class=product>
<a class=photo href="odincovo/product/chernila-dlya-canon-revcol-gi-490-magenta-dye-70-ml__661437075" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Чернила для Canon Revcol GI-490, Magenta, Dye, 70 мл." data-original="https://i.vestor-ru.ru/get-mpic/4725270/img_id3934209927373376381.png/200x200" data-lazy="https://i.vestor-ru.ru/get-mpic/4725270/img_id3934209927373376381.png/200x200"> </a>
<span class=price>
<span class=current>от 184<span class=rouble>i</span></span>
</span>
<a href="odincovo/product/chernila-dlya-canon-revcol-gi-490-magenta-dye-70-ml__661437075" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<iclass="no-a"></i>
</span>
<span class=count>3 отзыва</span>
</a>
<span class=delivery>доставка из Одинцово</span>
<a class=name href="odincovo/product/chernila-dlya-canon-revcol-gi-490-magenta-dye-70-ml__661437075" target=_blank>Чернила для Canon Revcol GI-490, Magenta, Dye, 70...</a>
</div>
<div class=product>
<a class=photo href="yalta/product/usb-riser-card-pci-e-x1-male-to-pci-e-x16-female-s-pitaniem-6pin-epciekit-ver-009s-espada__868729548" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="USB Riser card PCI-E x1 Male to PCI-E x16 Female с питанием 6Pin, EpciEkit (ver 009S), Espada" data-original="https://i.vestor-ru.ru/get-mpic/4937117/img_id2894366780074657021.jpeg/200x200" data-lazy="https://i.vestor-ru.ru/get-mpic/4937117/img_id2894366780074657021.jpeg/200x200"> </a>
<span class=price>
<span class=current>от 750<span class=rouble>i</span></span>
</span>
<a href="yalta/product/usb-riser-card-pci-e-x1-male-to-pci-e-x16-female-s-pitaniem-6pin-epciekit-ver-009s-espada__868729548" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<iclass="no-a"></i>
</span>
<span class=count>5 отзывов</span>
</a>
<span class=delivery>доставка из Ялты</span>
<a class=name href="yalta/product/usb-riser-card-pci-e-x1-male-to-pci-e-x16-female-s-pitaniem-6pin-epciekit-ver-009s-espada__868729548" target=_blank>USB Riser card PCI-E x1 Male to PCI-E x16 Female с...</a>
</div>
<div class=product>
<a class=photo href="saransk/product/usb-3-1-gen1-kontroller-orico-pvu3-7u__458454857" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="USB 3.1 Gen1 контроллер ORICO PVU3-7U" data-original="https://i.vestor-ru.ru/get-mpic/5165418/img_id1485278167576538711.jpeg/200x200" data-lazy="https://i.vestor-ru.ru/get-mpic/5165418/img_id1485278167576538711.jpeg/200x200"> </a>
<span class=price>
<span class=current>от 2 080<span class=rouble>i</span></span>
</span>
<a href="saransk/product/usb-3-1-gen1-kontroller-orico-pvu3-7u__458454857" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<i></i>
</span>
<span class=count>5 отзывов</span>
</a>
<span class=delivery>доставка из Саранска</span>
<a class=name href="saransk/product/usb-3-1-gen1-kontroller-orico-pvu3-7u__458454857" target=_blank>USB 3.1 Gen1 контроллер ORICO PVU3-7U</a>
</div>
<div class=product>
<a class=photo href="nn/product/96-kanalnaya-plata-pci-1753-ce-diskretnogo-vvoda-vyvoda__982885119" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="96-канальная плата PCI-1753-CE дискретного ввода/вывода" data-original="https://i.vestor-ru.ru/get-mpic/5234463/img_id3161417872115671095.png/200x200" data-lazy="https://i.vestor-ru.ru/get-mpic/5234463/img_id3161417872115671095.png/200x200"> </a>
<span class=price>
<span class=current>от 17 162<span class=rouble>i</span></span>
</span>
<a href="nn/product/96-kanalnaya-plata-pci-1753-ce-diskretnogo-vvoda-vyvoda__982885119" target=_blank class=rating>
</a>
<span class=delivery>доставка из Нижнего Новгорода</span>
<a class=name href="nn/product/96-kanalnaya-plata-pci-1753-ce-diskretnogo-vvoda-vyvoda__982885119" target=_blank>96-канальная плата PCI-1753-CE дискретного ввода/в...</a>
</div>
<div class=product>
<a class=photo href="vologda/product/usb-3-1-gen1-kontroller-orico-pvu3-2o2i__456847000" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="USB 3.1 Gen1 контроллер ORICO PVU3-2O2I" data-original="https://i.vestor-ru.ru/get-mpic/5165418/img_id6105981246179201475.jpeg/200x200" data-lazy="https://i.vestor-ru.ru/get-mpic/5165418/img_id6105981246179201475.jpeg/200x200"> </a>
<span class=price>
<span class=current>от 1 110<span class=rouble>i</span></span>
</span>
<a href="vologda/product/usb-3-1-gen1-kontroller-orico-pvu3-2o2i__456847000" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<iclass="no-a"></i>
</span>
<span class=count>10 отзывов</span>
</a>
<span class=delivery>доставка из Вологды</span>
<a class=name href="vologda/product/usb-3-1-gen1-kontroller-orico-pvu3-2o2i__456847000" target=_blank>USB 3.1 Gen1 контроллер ORICO PVU3-2O2I</a>
</div>
<div class=product>
<a class=photo href="dzerzhinskiy/product/raizer-espada-epciekit__1400594442" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Райзер ESPADA EpciEkit" data-original="https://i.vestor-ru.ru/get-mpic/5376959/img_id5092199770879390626.jpeg/200x200" data-lazy="https://i.vestor-ru.ru/get-mpic/5376959/img_id5092199770879390626.jpeg/200x200"> </a>
<span class=price>
<span class=current>от 795<span class=rouble>i</span></span>
</span>
<a href="dzerzhinskiy/product/raizer-espada-epciekit__1400594442" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<iclass="no-a"></i>
</span>
<span class=count>5 отзывов</span>
</a>
<span class=delivery>доставка из Дзержинского</span>
<a class=name href="dzerzhinskiy/product/raizer-espada-epciekit__1400594442" target=_blank>Райзер ESPADA EpciEkit</a>
</div> </div>
</div>
</div>
</div>
<div class=review-useful>
<div class=b-title>Полезные обзоры</div>
<div class=review-list data-controller=review-slider>
<a class=item data-fancybox=videoList href="//www.youtube.com/watch?v=lZNTjrKAfjk" rel=nofollow>
<span class=text>Как выбрать смартфон?</span>
<span class=img><img src="imves.php?w=120&amp;h=145&amp;crop&amp;s=//i.ytimg.com/vi/lZNTjrKAfjk/mqdefault.jpg" alt="Как выбрать смартфон?"></span>
</a>
<a class=item data-fancybox=videoList href="//www.youtube.com/watch?v=vVRtMODojBM" rel=nofollow>
<span class=text>Смартфон huawei shot x - обзор. смарт...</span>
<span class=img><img src="imves.php?w=120&amp;h=145&amp;crop&amp;s=//i.ytimg.com/vi/vVRtMODojBM/mqdefault.jpg" alt="Смартфон huawei shot x - обзор. смарт..."></span>
</a>
<a class=item data-fancybox=videoList href="//www.youtube.com/watch?v=opgIl_2R1Tc" rel=nofollow>
<span class=text>Детский смартфон</span>
<span class=img><img src="imves.php?w=120&amp;h=145&amp;crop&amp;s=//i.ytimg.com/vi/opgIl_2R1Tc/mqdefault.jpg" alt="Детский смартфон"></span>
</a>
<a class=item data-fancybox=videoList href="//www.youtube.com/watch?v=pm6DdKEQL7M" rel=nofollow>
<span class=text>Как почистить камеру смартфона от пыл...</span>
<span class=img><img src="imves.php?w=120&amp;h=145&amp;crop&amp;s=//i.ytimg.com/vi/pm6DdKEQL7M/mqdefault.jpg" alt="Как почистить камеру смартфона от пыл..."></span>
</a>
<a class=item data-fancybox=videoList href="//www.youtube.com/watch?v=m2bA-TQKujY" rel=nofollow>
<span class=text>Как выбрать смартфон, купить смартфон...</span>
<span class=img><img src="imves.php?w=120&amp;h=145&amp;crop&amp;s=//i.ytimg.com/vi/m2bA-TQKujY/mqdefault.jpg" alt="Как выбрать смартфон, купить смартфон..."></span>
</a>
<a class=item data-fancybox=videoList href="//www.youtube.com/watch?v=0zEMkSxShxI" rel=nofollow>
<span class=text>Разбитый смартфон</span>
<span class=img><img src="imves.php?w=120&amp;h=145&amp;crop&amp;s=//i.ytimg.com/vi/0zEMkSxShxI/mqdefault.jpg" alt="Разбитый смартфон"></span>
</a>
<a class=item data-fancybox=videoList href="//www.youtube.com/watch?v=rPHKf0mcxZA" rel=nofollow>
<span class=text>Самый стильный смартфон для бомжа </span>
<span class=img><img src="imves.php?w=120&amp;h=145&amp;crop&amp;s=//i.ytimg.com/vi/rPHKf0mcxZA/mqdefault.jpg" alt="Самый стильный смартфон для бомжа "></span>
</a>
<a class=item data-fancybox=videoList href="//www.youtube.com/watch?v=1XCdr80rtBM" rel=nofollow>
<span class=text>Смартфон как видеорегистратор</span>
<span class=img><img src="imves.php?w=120&amp;h=145&amp;crop&amp;s=//i.ytimg.com/vi/1XCdr80rtBM/mqdefault.jpg" alt="Смартфон как видеорегистратор"></span>
</a>
</div>
</div>
<!---->
<!---->
<!--<div class="review-useful">-->
<!--    <div class="b-title">Полезные обзоры</div>-->
<!--    <div class="review-list" data-controller="review-slider">-->
<!--        <a href=""><span class="text">Ноутбуки и компьютерная техника</span><span class="img"><img src="/themes/vestor/assets/img/videoreview/videoreview-1.png" alt=""></span></a>-->
<!--        <a href=""><span class="text">Планшеты и мобильные девайсы</span><span class="img"><img src="/themes/vestor/assets/img/videoreview/videoreview-2.png" alt=""></span></a>-->
<!--        <a href=""><span class="text">Наушники и звук</span><span class="img"><img src="/themes/vestor/assets/img/videoreview/videoreview-3.png" alt=""></span></a>-->
<!--        <a href=""><span class="text">Аксессуары</span><span class="img"><img src="/themes/vestor/assets/img/videoreview/videoreview-4.png" alt=""></span></a><a href=""><span class="text">Ноутбуки и компьютерная техника</span><span class="img"><img src="/themes/vestor/assets/img/videoreview/videoreview-5.png" alt=""></span></a><a href=""><span class="text">Наушники и звук</span><span class="img"><img src="/themes/vestor/assets/img/videoreview/videoreview-6.png" alt=""></span></a><a href=""><span class="text">Аксессуары</span><span class="img"><img src="/themes/vestor/assets/img/videoreview/videoreview-1.png" alt=""></span></a></div>-->
<!--</div>-->
<div class=category-add>
<div class=inner>
<div class=b-title__wrap>
<div class=b-title>Дополнительные категории</div>
</div>
<div class=categories-list><a href=category-91009>
<span class=ico>
<svg class=icon-c-computers>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#computers"></use>
</svg>
</span>
<span class=text>Компьютерная техника</span>
</a><a href=category-91461>
<span class=ico>
<svg class=icon-c-telefoni>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#telefoni"></use>
</svg>
</span>
<span class=text>Телефоны</span>
</a><a href=category-198119>
<span class=ico>
<svg class=icon-c-elektronika>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#elektronika"></use>
</svg>
</span>
<span class=text>Электроника</span>
</a><a href=category-198118>
<span class=ico>
<svg class=icon-c-bitovaya>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#bitovaya"></use>
</svg>
</span>
<span class=text>Бытовая техника</span>
</a><a href=category-90574>
<span class=ico>
<svg class=icon-c-klimat>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#klimat"></use>
</svg>
</span>
<span class=text>Климатическая техника</span>
</a><a href=category-14334539>
<span class=ico>
<svg class=icon-c-sport_pitanie>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#sport_pitanie"></use>
</svg>
</span>
<span class=text>Спортивное питание</span>
</a><a href=category-91242>
<span class=ico>
<svg class=icon-c-mus_instrumenti>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#mus_instrumenti"></use>
</svg>
</span>
<span class=text>Музыкальные инструменты</span>
</a><a href=category-90801>
<span class=ico>
<svg class=icon-c-dosug>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#dosug"></use>
</svg>
</span>
<span class=text>Досуг и развлечения</span>
</a><a href=category-90813>
<span class=ico>
<svg class=icon-c-jivotnie>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#jivotnie"></use>
</svg>
</span>
<span class=text>Товары для животных</span>
</a><a href=category-90829>
<span class=ico>
<svg class=icon-c-knigi>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#knigi"></use>
</svg>
</span>
<span class=text>Книги</span>
</a><a href=category-8475840>
<span class=ico>
<svg class=icon-c-apteka>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#apteka"></use>
</svg>
</span>
<span class=text>Аптека</span>
</a><a href=category-1618974>
<span class=ico>
<svg class=icon-c-instrumenti>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#instrumenti"></use>
</svg>
</span>
<span class=text>Инструменты</span>
</a><a href=category-90783>
<span class=ico>
<svg class=icon-c-igrushki>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#igrushki"></use>
</svg>
</span>
<span class=text>Игрушки и игры</span>
</a><a href=category-91735>
<span class=ico>
<svg class=icon-c-uslugi>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#uslugi"></use>
</svg>
</span>
<span class=text>Услуги</span>
</a><a href=category-90666>
<span class=ico>
<svg class=icon-c-dom_i_dacha>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#dom_i_dacha"></use>
</svg>
</span>
<span class=text>Дом и дача</span>
</a><a href=category-13021308>
<span class=ico>
<svg class=icon-c-metalloprokat>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#metalloprokat"></use>
</svg>
</span>
<span class=text>Металлопрокат</span>
</a><a href=category-90667>
<span class=ico>
<svg class=icon-c-textil>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#textil"></use>
</svg>
</span>
<span class=text>Текстиль</span>
</a><a href=category-6179129>
<span class=ico>
<svg class=icon-c-mebel>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#mebel"></use>
</svg>
</span>
<span class=text>Мебель</span>
</a><a href=category-91763>
<span class=ico>
<svg class=icon-c-oborudovanie>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#oborudovanie"></use>
</svg>
</span>
<span class=text>Оборудование</span>
</a><a href=category-91512>
<span class=ico>
<svg class=icon-c-sport>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#sport"></use>
</svg>
</span>
<span class=text>Спорт и отдых</span>
</a><a href=category-91514>
<span class=ico>
<svg class=icon-c-oxota>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#oxota"></use>
</svg>
</span>
<span class=text>Охота и рыбалка</span>
</a><a href=category-91597>
<span class=ico>
<svg class=icon-c-remont>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#remont"></use>
</svg>
</span>
<span class=text>Строительство и ремонт</span>
</a><a href=category-91609>
<span class=ico>
<svg class=icon-c-santexnika>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#santexnika"></use>
</svg>
</span>
<span class=text>Сантехника и водоснабжение</span>
</a><a href=category-90509>
<span class=ico>
<svg class=icon-c-krasota>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#krasota"></use>
</svg>
</span>
<span class=text>Красота и здоровье</span>
</a><a href=category-10604368>
<span class=ico>
<svg class=icon-c-orgtexnika>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#orgtexnika"></use>
</svg>
</span>
<span class=text>Оргтехника</span>
</a><a href=category-91307>
<span class=ico>
<svg class=icon-c-produkti>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#produkti"></use>
</svg>
</span>
<span class=text>Продукты</span>
</a><a href=category-15068776>
<span class=ico>
<svg class=icon-c-ukrasheniya>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#ukrasheniya"></use>
</svg>
</span>
<span class=text>Украшения</span>
</a><a href=category-14910177>
<span class=ico>
<svg class=icon-c-stanki>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#stanki"></use>
</svg>
</span>
<span class=text>Станки</span>
</a><a href=category-7812195>
<span class=ico>
<svg class=icon-c-sumki>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#sumki"></use>
</svg>
</span>
<span class=text>Сумки и чемоданы</span>
</a><a href=category-90722>
<span class=ico>
<svg class=icon-c-ofis>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#ofis"></use>
</svg>
</span>
<span class=text>Все для офиса</span>
</a><a href=category-15064473>
<span class=ico>
<svg class=icon-c-chasi>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#chasi"></use>
</svg>
</span>
<span class=text>Часы</span>
</a><a href=category-90708>
<span class=ico>
<svg class=icon-c-osveshenie>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#osveshenie"></use>
</svg>
</span>
<span class=text>Освещение</span>
</a><a href=category-90402>
<span class=ico>
<svg class=icon-c-avto>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#avto"></use>
</svg>
</span>
<span class=text>Авто</span>
</a><a href=category-1006243>
<span class=ico>
<svg class=icon-c-trenajeri>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#trenajeri"></use>
</svg>
</span>
<span class=text>Тренажеры и фитнес</span>
</a><a href=category-7877999>
<span class=ico>
<svg class=icon-c-odejda>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#odejda"></use>
</svg>
</span>
<span class=text>Одежда, обувь и аксессуары</span>
</a><a href=category-90764>
<span class=ico>
<svg class=icon-c-detskie_tovari>
<use xlink:href="/themes/vestor/assets/img/categories/sprite.svg#detskie_tovari"></use>
</svg>
</span>
<span class=text>Детские товары</span>
</a></div> </div>
</div>
<div class=articles-useful>
<div class=b-title>Полезные статьи</div>
<div class=list data-controller=articles-slider>
<a href="article/naryad-dlya-lki">
<div class=heading>
<span class=ico>
<svg class=icon-c-collectibles>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#c-collectibles"></use>
</svg>
</span>
<span class=title>
<span class=caption>История елочных игрушек от истоков до настоящих дней</span>
<span class=date>17 декабря 2019</span>
</span>
</div>
<div class=inner>
<div class=text>
<p>Подробная история возникновения елочных игрушек. Как наряжать елку в Новый Год? Более подробно на сайте компании "Vestor"</p>
<span class=link>Подробнее</span>
</div>
<div class=photos>
<img src="https://i.vestor-ru.ru/uploads/news/shutterstock238030588.jpg" alt="История елочных игрушек от истоков до настоящих дней">
</div>
</div>
</a>
<a href="article/bizi-dlya-detei">
<div class=heading>
<span class=ico>
<svg class=icon-c-collectibles>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#c-collectibles"></use>
</svg>
</span>
<span class=title>
<span class=caption>Что такое Бизи и чем игрушка полезна для детей</span>
<span class=date>17 декабря 2019</span>
</span>
</div>
<div class=inner>
<div class=text>
<p>Чем полезна Бизи игрушка для Вашего ребенка? Как Бизи развивает мелкую моторику у детей. Более подробно на сайте компании "Vestor"</p>
<span class=link>Подробнее</span>
</div>
<div class=photos>
<img src="https://i.vestor-ru.ru/uploads/news/shutterstock1570981870.jpg" alt="Что такое Бизи и чем игрушка полезна для детей">
</div>
</div>
</a>
<a href="article/kruti-pedali">
<div class=heading>
<span class=ico>
<svg class=icon-c-collectibles>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#c-collectibles"></use>
</svg>
</span>
<span class=title>
<span class=caption>Первый велосипед для ребенка - инструкция по выбору</span>
<span class=date>17 декабря 2019</span>
</span>
</div>
<div class=inner>
<div class=text>
<p>Как выбрать первый велосипед для ребенка? На что необходимо обратить внимание при покупке? Более подробно на сайте компании "Vestor"</p>
<span class=link>Подробнее</span>
</div>
<div class=photos>
<img src="https://i.vestor-ru.ru/uploads/news/shutterstock1355678030.jpg" alt="Первый велосипед для ребенка - инструкция по выбору">
</div>
</div>
</a>
<a href="article/palatka">
<div class=heading>
<span class=ico>
<svg class=icon-c-collectibles>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#c-collectibles"></use>
</svg>
</span>
<span class=title>
<span class=caption>Как выбрать палатку - практические советы</span>
<span class=date>17 декабря 2019</span>
</span>
</div>
<div class=inner>
<div class=text>
<p>Выбор палатки для похода - важный шаг для любого путешественника. Особенности конструкций палаток и критерии выбора. Более подробно на сайте компании</p>
<span class=link>Подробнее</span>
</div>
<div class=photos>
<img src="https://i.vestor-ru.ru/uploads/news/shutterstock239086093.jpg" alt="Как выбрать палатку - практические советы">
</div>
</div>
</a>
<a href="article/slezy-rusalok">
<div class=heading>
<span class=ico>
<svg class=icon-c-collectibles>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#c-collectibles"></use>
</svg>
</span>
<span class=title>
<span class=caption>Как добывают жемчуг - подробная информация</span>
<span class=date>17 декабря 2019</span>
</span>
</div>
<div class=inner>
<div class=text>
<p>Статья о происхождении жемчуга, его использовании в изготовлении ювелирных изделий. Более подробно на сайте компании "Vestor"</p>
<span class=link>Подробнее</span>
</div>
<div class=photos>
<img src="https://i.vestor-ru.ru/uploads/news/shutterstock1162392064.jpg" alt="Как добывают жемчуг - подробная информация">
</div>
</div>
</a>
<a href="article/letyaschei-pohodkoi">
<div class=heading>
<span class=ico>
<svg class=icon-c-collectibles>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#c-collectibles"></use>
</svg>
</span>
<span class=title>
<span class=caption>Как правильно выбрать обувь для повседневной носки?</span>
<span class=date>17 декабря 2019</span>
</span>
</div>
<div class=inner>
<div class=text>
<p>Типы стоп и подбор обуви для повседневной носки. Как правильно выбрать обувь? Более подробно на сайте компании "Vestor"</p>
<span class=link>Подробнее</span>
</div>
<div class=photos>
<img src="https://i.vestor-ru.ru/uploads/news/shutterstock547453213.jpg" alt="Как правильно выбрать обувь для повседневной носки?">
</div>
</div>
</a>
<a href="article/avtorskie-zalomy-na-dzhinsah">
<div class=heading>
<span class=ico>
<svg class=icon-c-collectibles>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#c-collectibles"></use>
</svg>
</span>
<span class=title>
<span class=caption>Как выбрать джинсы правильно - практические советы</span>
<span class=date>17 декабря 2019</span>
</span>
</div>
<div class=inner>
<div class=text>
<p>Уход за джинсами: как стирать, как избавиться от заломов, как продлить жизнь? Это и многое другое в статье на сайте компании "Vestor"</p>
<span class=link>Подробнее</span>
</div>
<div class=photos>
<img src="https://i.vestor-ru.ru/uploads/news/shutterstock1383077573.jpg" alt="Как выбрать джинсы правильно - практические советы">
</div>
</div>
</a>
<a href="article/parovarka">
<div class=heading>
<span class=ico>
<svg class=icon-c-collectibles>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#c-collectibles"></use>
</svg>
</span>
<span class=title>
<span class=caption>Как выбрать пароварку - практические советы</span>
<span class=date>17 декабря 2019</span>
</span>
</div>
<div class=inner>
<div class=text>
<p>Что такое пароварка и какие виды пароварок существуют? Критерии выбора и необходимость данного агрегата на кухне. Более подробно на сайте компании "Ve...</p>
<span class=link>Подробнее</span>
</div>
<div class=photos>
<img src="https://i.vestor-ru.ru/uploads/news/shutterstock1014983272.jpg" alt="Как выбрать пароварку - практические советы">
</div>
</div>
</a>
<a href="article/posudomoechnaya-mashina">
<div class=heading>
<span class=ico>
<svg class=icon-c-collectibles>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#c-collectibles"></use>
</svg>
</span>
<span class=title>
<span class=caption>Нужна ли посудомоечная машина на кухне? - все плюсы и минусы</span>
<span class=date>17 декабря 2019</span>
</span>
</div>
<div class=inner>
<div class=text>
<p>Зачем нужна посудомойка? Все преимущества и недостатки этой бытовой техники - это и многое другое в статье на сайте компании "Vestor"</p>
<span class=link>Подробнее</span>
</div>
<div class=photos>
<img src="https://i.vestor-ru.ru/uploads/news/shutterstock1295668432-1.jpg" alt="Нужна ли посудомоечная машина на кухне? - все плюсы и минусы">
</div>
</div>
</a>
<a href="article/skolko-na-elochke-sharikov-cvetnyh">
<div class=heading>
<span class=ico>
<svg class=icon-c-collectibles>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#c-collectibles"></use>
</svg>
</span>
<span class=title>
<span class=caption>Как и чем наряжают новогоднюю елку - практические советы</span>
<span class=date>17 декабря 2019</span>
</span>
</div>
<div class=inner>
<div class=text>
<p>Шары, пряники, гирлянды, мишура - это далеко не весь список новогодних игрушек, которыми наряжают елку. Более подробно о елочных украшениях на сайте к...</p>
<span class=link>Подробнее</span>
</div>
<div class=photos>
<img src="https://i.vestor-ru.ru/uploads/news/shutterstock1196745076.jpg" alt="Как и чем наряжают новогоднюю елку - практические советы">
</div>
</div>
</a>
<a href="article/kak-vybrat-kolyasku">
<div class=heading>
<span class=ico>
<svg class=icon-c-collectibles>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#c-collectibles"></use>
</svg>
</span>
<span class=title>
<span class=caption>Как выбрать коляску для ребенка - практические советы</span>
<span class=date>17 декабря 2019</span>
</span>
</div>
<div class=inner>
<div class=text>
<p>Выбор коляски для новорожденного - это ответственный шаг для каждой мамы. Подробнее о видах колясок и их преимуществах читайте на сайте компании "Vest...</p>
<span class=link>Подробнее</span>
</div>
<div class=photos>
<img src="https://i.vestor-ru.ru/uploads/news/shutterstock167670155.jpg" alt="Как выбрать коляску для ребенка - практические советы">
</div>
</div>
</a>
</div>
</div>
<div class="products-widget popular">
<div class=b-title>Популярные товары</div>
<div class=inner>
<div class=products-list>
<div class=product>
<a class=photo href="https://market.yandex.ru/search?text=%D0%A1%D0%BC%D0%B0%D1%80%D1%82%D1%84%D0%BE%D0%BD+Xiaomi+Poco+X3+Pro+8%2F256GB&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Смартфон Xiaomi Poco X3 Pro 8/256GB" data-original="https://i.vestor-ru.ru/get-mpic/4365206/img_id3313110072182201126.jpeg/200x200"> </a>
<a href="https://market.yandex.ru/search?text=%D0%A1%D0%BC%D0%B0%D1%80%D1%82%D1%84%D0%BE%D0%BD+Xiaomi+Poco+X3+Pro+8%2F256GB&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank class=price>
<span class=current>от 21 140<span class=rouble>i</span></span>
</a>
<a href="https://market.yandex.ru/product/870124073/reviews?clid=2376175&track=partner" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<iclass="no-a"></i>
</span>
<span class=count>614 отзывов</span>
</a>
<span class=delivery>доставка из Дзержинска</span>
<a class=name href="https://market.yandex.ru/search?text=%D0%A1%D0%BC%D0%B0%D1%80%D1%82%D1%84%D0%BE%D0%BD+Xiaomi+Poco+X3+Pro+8%2F256GB&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank>Смартфон Xiaomi Poco X3 Pro 8/256GB</a>
<a href="product/smartfon-xiaomi-poco-x3-pro-8-256gb__870124073" class=info-data-ya>
<div class=item_delivery_origin>
<div class=descriptiontext>
Диагональ экрана: 6.67", количество основных камер: 4, память: 256 ГБ, оперативная память: 8 ГБ, емкость аккумулятора: 5160 мА⋅ч, разрешение экрана: 2400x1080, частота обновления экрана: 120 Гц, NFC, 4G LTE, 2 SIM-карты, слот для карты памяти </div>
<div class=item-bottom>данные с Яндекс Маркета</div>
</div>
</a>
</div>
<div class=product>
<a class=photo href="https://market.yandex.ru/search?text=%D0%9D%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA+Asus+Laptop+12+L210MA-GJ163T+%2890NB0R44-M06090%29+%D1%87%D0%B5%D1%80%D0%BD%D1%8B%D0%B9&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Ноутбук Asus Laptop 12 L210MA-GJ163T (90NB0R44-M06090) черный" data-original="https://i.vestor-ru.ru/get-mpic/5252116/img_id8179812437728878109.jpeg/200x200"> </a>
<a href="https://market.yandex.ru/search?text=%D0%9D%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA+Asus+Laptop+12+L210MA-GJ163T+%2890NB0R44-M06090%29+%D1%87%D0%B5%D1%80%D0%BD%D1%8B%D0%B9&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank class=price>
<span class=current>от 21 900<span class=rouble>i</span></span>
</a>
<a href="https://market.yandex.ru/product/999454523/reviews?clid=2376175&track=partner" target=_blank class=rating>
</a>
<span class=delivery>доставка из Норильска</span>
<a class=name href="https://market.yandex.ru/search?text=%D0%9D%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA+Asus+Laptop+12+L210MA-GJ163T+%2890NB0R44-M06090%29+%D1%87%D0%B5%D1%80%D0%BD%D1%8B%D0%B9&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank>Ноутбук Asus Laptop 12 L210MA-GJ163T (90NB0R44-M06...</a>
<a href="product/noutbuk-asus-laptop-12-l210ma-gj163t-90nb0r44-m06090-chernyi__999454523" class=info-data-ya>
<div class=item_delivery_origin>
<div class=descriptiontext>
11.60", 1366x768, 1.10кг, Windows 10 Home </div>
<div class=item-bottom>данные с Яндекс Маркета</div>
</div>
</a>
</div>
<div class=product>
<a class=photo href="https://market.yandex.ru/search?text=%D0%A1%D0%BC%D0%B0%D1%80%D1%82%D1%84%D0%BE%D0%BD+Sony+Xperia+10+II+Dual&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Смартфон Sony Xperia 10 II Dual" data-original="https://i.vestor-ru.ru/get-mpic/1704691/img_id3109376883906299619.jpeg/200x200"> </a>
<a href="https://market.yandex.ru/search?text=%D0%A1%D0%BC%D0%B0%D1%80%D1%82%D1%84%D0%BE%D0%BD+Sony+Xperia+10+II+Dual&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank class=price>
<span class=current>от 23 770<span class=rouble>i</span></span>
</a>
<a href="https://market.yandex.ru/product/655130271/reviews?clid=2376175&track=partner" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<iclass="no-a"></i>
</span>
<span class=count>140 отзывов</span>
</a>
<span class=delivery>доставка из Коврова</span>
<a class=name href="https://market.yandex.ru/search?text=%D0%A1%D0%BC%D0%B0%D1%80%D1%82%D1%84%D0%BE%D0%BD+Sony+Xperia+10+II+Dual&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank>Смартфон Sony Xperia 10 II Dual</a>
<a href="product/smartfon-sony-xperia-10-ii-dual__655130271" class=info-data-ya>
<div class=item_delivery_origin>
<div class=descriptiontext>
Sony Xperia 10 II Dual — комфортный 3-камерный телефон. Модель получила отличный дисплей, 8-ядерный чип Snapdragon, широкоугольную оптику. Используется кинематографический формат 21:9. Просмотр контента очень приятен. Заряда может хватить на 5-6 часов наслаждения 3D-игр... </div>
<div class=item-bottom>данные с Яндекс Маркета</div>
</div>
</a>
</div>
<div class=product>
<a class=photo href="https://market.yandex.ru/search?text=%D0%9D%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA+ASUS+X415MA-EK052+%28Intel+Pentium+N5030+1100MHz%2F14%22%2F1920x1080%2F4GB%2F128GB+SSD%2FIntel+UHD+Graphics%2F%D0%91%D0%B5%D0%B7+%D0%9E%D0%A1%29+90NB0TG2-M03030%2C+slate+grey&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Ноутбук ASUS X415MA-EK052 (Intel Pentium N5030 1100MHz/14&quot;/1920x1080/4GB/128GB SSD/Intel UHD Graphics/Без ОС) 90NB0TG2-M03030, slate grey" data-original="https://i.vestor-ru.ru/get-mpic/4383514/img_id4319711280114165502.jpeg/200x200"> </a>
<a href="https://market.yandex.ru/search?text=%D0%9D%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA+ASUS+X415MA-EK052+%28Intel+Pentium+N5030+1100MHz%2F14%22%2F1920x1080%2F4GB%2F128GB+SSD%2FIntel+UHD+Graphics%2F%D0%91%D0%B5%D0%B7+%D0%9E%D0%A1%29+90NB0TG2-M03030%2C+slate+grey&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank class=price>
<span class=current>от 27 162<span class=rouble>i</span></span>
</a>
<a href="https://market.yandex.ru/product/897163634/reviews?clid=2376175&track=partner" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<iclass="no-a"></i>
</span>
<span class=count>7 отзывов</span>
</a>
<span class=delivery>доставка из Таганрога</span>
<a class=name href="https://market.yandex.ru/search?text=%D0%9D%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA+ASUS+X415MA-EK052+%28Intel+Pentium+N5030+1100MHz%2F14%22%2F1920x1080%2F4GB%2F128GB+SSD%2FIntel+UHD+Graphics%2F%D0%91%D0%B5%D0%B7+%D0%9E%D0%A1%29+90NB0TG2-M03030%2C+slate+grey&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank>Ноутбук ASUS X415MA-EK052 (Intel Pentium N5030 110...</a>
<a href="product/noutbuk-asus-x415ma-ek052-intel-pentium-n5030-1100mhz-14--1920x1080-4gb-128gb-ssd-intel-uhd-graphics-bez-os-90nb0tg2-m03030-slate-grey__897163634" class=info-data-ya>
<div class=item_delivery_origin>
<div class=descriptiontext>
14", 1920x1080, 1.50кг, Без ОС </div>
<div class=item-bottom>данные с Яндекс Маркета</div>
</div>
</a>
</div>
<div class=product>
<a class=photo href="https://market.yandex.ru/search?text=%D0%A1%D0%BC%D0%B0%D1%80%D1%82%D1%84%D0%BE%D0%BD+vivo+Y31&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Смартфон vivo Y31" data-original="https://i.vestor-ru.ru/get-mpic/4386141/img_id564591287440324432.jpeg/200x200"> </a>
<a href="https://market.yandex.ru/search?text=%D0%A1%D0%BC%D0%B0%D1%80%D1%82%D1%84%D0%BE%D0%BD+vivo+Y31&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank class=price>
<span class=current>от 16 990<span class=rouble>i</span></span>
</a>
<a href="https://market.yandex.ru/product/835005007/reviews?clid=2376175&track=partner" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<i></i>
</span>
<span class=count>330 отзывов</span>
</a>
<span class=delivery>доставка из Первоуральска</span>
<a class=name href="https://market.yandex.ru/search?text=%D0%A1%D0%BC%D0%B0%D1%80%D1%82%D1%84%D0%BE%D0%BD+vivo+Y31&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank>Смартфон vivo Y31</a>
<a href="product/smartfon-vivo-y31__835005007" class=info-data-ya>
<div class=item_delivery_origin>
<div class=descriptiontext>
Оснащен дисплеем Halo FullView с диагональю 6,58 дюйма, разрешением Full HD&#43; (2408 x 1080) и поддержкой цветовой палитры P3, чтобы вы смогли целиком погрузиться в мир игр и видео. Для снижения нагрузки на глаза в смартфоне предусмотрена функция фильтрации вредного с... </div>
<div class=item-bottom>данные с Яндекс Маркета</div>
</div>
</a>
</div>
<div class=product>
<a class=photo href="https://market.yandex.ru/search?text=%D0%9D%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA+ASUS+ASUSPRO+P5440FA-BM1028+%28Intel+Core+i3+8145U+2100MHz%2F14%22%2F1920x1080%2F8GB%2F256GB+SSD%2FDVD+%D0%BD%D0%B5%D1%82%2FIntel+UHD+Graphics+620%2FWi-Fi%2FBluetooth%2F%D0%91%D0%B5%D0%B7+%D0%9E%D0%A1%29&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank>
<img class="item_img lazy" src="themes/vestor/assets/img/thumb.webp" alt="Ноутбук ASUS ASUSPRO P5440FA-BM1028 (Intel Core i3 8145U 2100MHz/14&quot;/1920x1080/8GB/256GB SSD/DVD нет/Intel UHD Graphics 620/Wi-Fi/Bluetooth/Без ОС)" data-original="https://i.vestor-ru.ru/get-mpic/1912364/img_id2115423915251951923.jpeg/200x200"> </a>
<a href="https://market.yandex.ru/search?text=%D0%9D%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA+ASUS+ASUSPRO+P5440FA-BM1028+%28Intel+Core+i3+8145U+2100MHz%2F14%22%2F1920x1080%2F8GB%2F256GB+SSD%2FDVD+%D0%BD%D0%B5%D1%82%2FIntel+UHD+Graphics+620%2FWi-Fi%2FBluetooth%2F%D0%91%D0%B5%D0%B7+%D0%9E%D0%A1%29&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank class=price>
<span class=current>от 41 900<span class=rouble>i</span></span>
</a>
<a href="https://market.yandex.ru/product/674399002/reviews?clid=2376175&track=partner" target=_blank class=rating>
<span class=stars>
<i></i>
<i></i>
<i></i>
<i></i>
<iclass="no-a"></i>
</span>
<span class=count>10 отзывов</span>
</a>
<span class=delivery>доставка из Ханты-Мансийска</span>
<a class=name href="https://market.yandex.ru/search?text=%D0%9D%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA+ASUS+ASUSPRO+P5440FA-BM1028+%28Intel+Core+i3+8145U+2100MHz%2F14%22%2F1920x1080%2F8GB%2F256GB+SSD%2FDVD+%D0%BD%D0%B5%D1%82%2FIntel+UHD+Graphics+620%2FWi-Fi%2FBluetooth%2F%D0%91%D0%B5%D0%B7+%D0%9E%D0%A1%29&pp=900&mclid=1003&distr_type=7&vid=2&clid=2376175" target=_blank>Ноутбук ASUS ASUSPRO P5440FA-BM1028 (Intel Core i3...</a>
<a href="product/noutbuk-asus-asuspro-p5440fa-bm1028-intel-core-i3-8145u-2100mhz-14--1920x1080-8gb-256gb-ssd-dvd-net-intel-uhd-graphics-620-wi-fi-bluetooth-bez-os__674399002" class=info-data-ya>
<div class=item_delivery_origin>
<div class=descriptiontext>
14", 1920x1080, 1.23кг, DOS, Без ОС, Windows 10 Pro </div>
<div class=item-bottom>данные с Яндекс Маркета</div>
</div>
</a>
</div> </div>
</div>
</div>
</div>
</div>
<footer class=footer>
<div class=contacts>
<div class=container>
<div class=inner>
<div class=box>
<span class=title>Есть вопросы? Напишите нам</span>
<span class=email>
<a href="mailto:support@vestor-ru.ru" target=_blank>support@vestor-ru.ru</a>
</span>
<span class=text>Каждый день, с 09:00 - 19:00</span>
</div>
<div class=box><span class=title>Следите за нами в соц. сетях</span>
<ul class=soc>
<li><a class=fb href="https://www.facebook.com/" target=_blank>
<svg class=icon-s_fb>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#s_fb"></use>
</svg>
</a></li>
<li><a class=inst href="https://www.instagram.com/" target=_blank>
<svg class=icon-s_inst>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#s_inst"></use>
</svg>
</a></li>
<li><a class=ytb href="https://www.youtube.com/" target=_blank>
<svg class=icon-s_ytb>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#s_ytb"></use>
</svg>
</a></li>
<li><a class=tw href="https://twitter.com/home" target=_blank>
<svg class=icon-s_tw>
<use xlink:href="/themes/vestor/assets/img/sprite.svg#s_tw"></use>
</svg>
</a></li>
</ul>
</div>
</div>
</div>
</div>
<div class=container>
<div class=nav>
<div class=box>
<span class=title>О компании</span>
<ul>
<li><a href=o-nas>О нас</a></li>
<li><a href=goroda>Города</a></li>
<li><a href=polzovatelskoe-soglashenie>Пользовательское соглашение</a></li>
<li><a href=politika-konfendicialnosti>Политика конфиденциальности</a></li>
</ul>
</div>
<div class=box>
<span class=title>&nbsp;</span>
<ul>
<li><a href=poisk-tovarov-na-vestor-ru-ru>Как найти нужный товар</a></li>
<li><a href=vozvrat-i-obmen-tovara>Возврат и обмен товара</a></li>
<li><a href=oplata-i-dostavka>Оплата и доставка</a></li>
</ul>
</div>
<div class=copyright><span class=text>© 2003 - 2021 vestor-ru.ru </span>
<div class=source>
<span class=caption>Источник данных: </span>
<span class=links>
<a href="https://market.yandex.ru/" rel=nofollow target=_blank>Яндекс.Маркет</a><span>|</span>
<a href="https://www.youtube.com/" target=_blank>YouTube</a>
</span>
</div>
</div>
</div>
</div>
</footer>
<script src="themes/vestor/web_assets/js/vestor_script.js"></script> </body>
</html>
